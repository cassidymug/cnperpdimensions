// CNPERP ERP System - Standardized Navbar Component
// This file provides a consistent, clean navigation bar across all pages
// Includes offline-friendly styling

// Add offline-friendly CSS
function addOfflineStyles() {
	if (!document.getElementById('offline-navbar-styles')) {
		const style = document.createElement('style');
		style.id = 'offline-navbar-styles';
		style.textContent = `
			/* Offline-friendly navbar styles */
			.navbar {
				background-color: #0d6efd !important;
				padding: 0.5rem 1rem;
				box-shadow: 0 2px 4px rgba(0,0,0,0.1);
			}
			.navbar-brand {
				color: white !important;
				font-weight: bold;
				text-decoration: none;
				font-size: 1.25rem;
			}
			.navbar-nav .nav-link {
				color: rgba(255,255,255,0.8) !important;
				padding: 0.5rem 1rem;
				text-decoration: none;
				transition: color 0.2s;
			}
			.navbar-nav .nav-link:hover {
				color: white !important;
			}
			.navbar-nav .nav-link.active {
				color: white !important;
				font-weight: 600;
			}
			.navbar-toggler {
				border: 1px solid rgba(255,255,255,0.5);
				padding: 0.25rem 0.5rem;
			}
			.navbar-toggler-icon {
				background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.8%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
			}
			.dropdown-menu {
				background-color: white;
				border: 1px solid #dee2e6;
				border-radius: 0.375rem;
				box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.15);
				padding: 0.5rem 0;
				margin: 0;
				list-style: none;
			}
			.dropdown-item {
				color: #212529;
				padding: 0.5rem 1rem;
				text-decoration: none;
				display: block;
			}
			.dropdown-item:hover {
				background-color: #f8f9fa;
				color: #212529;
			}
			.dropdown-divider {
				border-top: 1px solid #dee2e6;
				margin: 0.5rem 0;
			}
			/* Basic icon fallbacks */
			.bi {
				display: inline-block;
				width: 1em;
				height: 1em;
				vertical-align: -0.125em;
			}
			.bi-building::before { content: "🏢"; }
			.bi-speedometer2::before { content: "📊"; }
			.bi-calculator::before { content: "🧮"; }
			.bi-file-earmark-text::before { content: "📄"; }
			.bi-cash-stack::before { content: "💰"; }
			.bi-box-seam::before { content: "📦"; }
			.bi-clipboard-check::before { content: "📋"; }
			.bi-cart::before { content: "🛒"; }
			.bi-truck::before { content: "🚚"; }
			.bi-bank::before { content: "🏦"; }
			.bi-percent::before { content: "%"; }
			.bi-hdd-stack::before { content: "💾"; }
			.bi-gear::before { content: "⚙️"; }
			.bi-person-circle::before { content: "👤"; }
		`;
		document.head.appendChild(style);
	}
}

function createNavbar(currentPage = 'dashboard') {
	// Add offline styles
	addOfflineStyles();
	
	return `
	<nav class="navbar navbar-expand-lg">
		<div class="container-fluid">
			<a class="navbar-brand" href="/static/index.html">
				<span class="bi bi-building"></span> CNPERP ERP
			</a>
			
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarContent">
				<ul class="navbar-nav me-auto">
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'dashboard' ? 'active' : ''}" href="/static/index.html">
							<span class="bi bi-speedometer2"></span> Dashboard
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'accounting' ? 'active' : ''}" href="/static/chart-of-accounts.html">
							<span class="bi bi-calculator"></span> Accounting
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'reports' ? 'active' : ''}" href="/static/reports.html">
							<span class="bi bi-file-earmark-text"></span> Reports
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'budgeting' ? 'active' : ''}" href="/static/budgeting.html">
							<span class="bi bi-cash-stack"></span> Budgeting
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'inventory' ? 'active' : ''}" href="/static/products.html">
							<span class="bi bi-box-seam"></span> Inventory
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'procurement' ? 'active' : ''}" href="/static/procurement.html">
							<span class="bi bi-clipboard-check"></span> Procurement
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'sales' ? 'active' : ''}" href="/static/sales.html">
							<span class="bi bi-cart"></span> Sales
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'purchases' ? 'active' : ''}" href="/static/purchases.html">
							<span class="bi bi-truck"></span> Purchases
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'banking' ? 'active' : ''}" href="/static/bank-accounts.html">
							<span class="bi bi-bank"></span> Banking
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'tax' ? 'active' : ''}" href="/static/vat-reports.html">
							<span class="bi bi-percent"></span> Tax
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'assets' ? 'active' : ''}" href="/static/asset-management.html">
							<span class="bi bi-hdd-stack"></span> Assets
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link ${currentPage === 'setup' ? 'active' : ''}" href="/static/settings.html">
							<span class="bi bi-gear"></span> Setup
						</a>
					</li>
				</ul>
				
				<ul class="navbar-nav">
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
							<span class="bi bi-person-circle"></span> Admin
						</a>
						<ul class="dropdown-menu dropdown-menu-end">
							<li><a class="dropdown-item" href="/static/admin-panel.html">Admin Panel</a></li>
							<li><a class="dropdown-item" href="/static/users.html">Users</a></li>
							<li><a class="dropdown-item" href="/static/settings.html">Settings</a></li>
							<li><a class="dropdown-item" href="/static/backup-management.html">Backup Management</a></li>
							<li><hr class="dropdown-divider"></li>
							<li><a class="dropdown-item" href="#" onclick="logout()">Logout</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	`;
}

// Function to initialize navbar on any page
function initializeNavbar(currentPage = 'dashboard') {
	const navbarContainer = document.getElementById('navbar-container');
	if (navbarContainer) {
		navbarContainer.innerHTML = createNavbar(currentPage);
	}
}

// Function to handle logout
function logout() {
	if (confirm('Are you sure you want to logout?')) {
		// Clear any stored data
		localStorage.removeItem('user_token');
		localStorage.removeItem('user_data');
		
		// Redirect to login or dashboard
		window.location.href = '/static/index.html';
	}
}

// Check if Bootstrap is available
function isBootstrapAvailable() {
	return typeof bootstrap !== 'undefined' && bootstrap.Modal;
}

// Add basic Bootstrap functionality if not available
function addBootstrapFallback() {
	if (!isBootstrapAvailable()) {
		console.log('⚠️ Bootstrap not available, adding fallback functionality');
		
		// Add basic dropdown functionality
		document.addEventListener('click', function(e) {
			if (e.target.classList.contains('dropdown-toggle')) {
				e.preventDefault();
				const dropdown = e.target.closest('.dropdown');
				const menu = dropdown.querySelector('.dropdown-menu');
				
				// Close other dropdowns
				document.querySelectorAll('.dropdown-menu').forEach(m => {
					if (m !== menu) m.style.display = 'none';
				});
				
				// Toggle current dropdown
				menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
			} else if (!e.target.closest('.dropdown')) {
				// Close all dropdowns when clicking outside
				document.querySelectorAll('.dropdown-menu').forEach(m => {
					m.style.display = 'none';
				});
			}
		});
		
		// Add basic collapse functionality
		document.addEventListener('click', function(e) {
			if (e.target.classList.contains('navbar-toggler')) {
				e.preventDefault();
				const target = e.target.getAttribute('data-bs-target');
				const element = document.querySelector(target);
				if (element) {
					element.classList.toggle('show');
				}
			}
		});
	}
}

// Auto-initialize navbar if navbar-container exists
document.addEventListener('DOMContentLoaded', function() {
	// Add Bootstrap fallback
	addBootstrapFallback();
	
	const navbarContainer = document.getElementById('navbar-container');
	if (navbarContainer) {
		// Determine current page from URL
		const currentPath = window.location.pathname;
		let currentPage = 'dashboard';
		
		if (currentPath.includes('products')) currentPage = 'inventory';
		else if (currentPath.includes('customers')) currentPage = 'sales';
		else if (currentPath.includes('sales')) currentPage = 'sales';
		else if (currentPath.includes('purchases')) currentPage = 'purchases';
		else if (currentPath.includes('suppliers')) currentPage = 'purchases';
		else if (currentPath.includes('bank-accounts')) currentPage = 'banking';
		else if (currentPath.includes('bank-transactions')) currentPage = 'banking';
		else if (currentPath.includes('bank-transfers')) currentPage = 'banking';
		else if (currentPath.includes('bank-reconciliations')) currentPage = 'banking';
		else if (currentPath.includes('journal-entries')) currentPage = 'accounting';
		else if (currentPath.includes('ledgers')) currentPage = 'accounting';
		else if (currentPath.includes('chart-of-accounts')) currentPage = 'accounting';
		else if (currentPath.includes('users')) currentPage = 'setup';
		else if (currentPath.includes('branches')) currentPage = 'setup';
		else if (currentPath.includes('settings')) currentPage = 'setup';
		else if (currentPath.includes('pos')) currentPage = 'sales';
		else if (currentPath.includes('invoices')) currentPage = 'sales';
		else if (currentPath.includes('vat-reconciliations')) currentPage = 'tax';
		else if (currentPath.includes('vat-reports')) currentPage = 'tax';
		else if (currentPath.includes('purchase-orders')) currentPage = 'purchases';
		else if (currentPath.includes('accounting-codes')) currentPage = 'accounting';
		else if (currentPath.includes('reports')) currentPage = 'reports';
		else if (currentPath.includes('financial-reports')) currentPage = 'reports';
		else if (currentPath.includes('asset-management')) currentPage = 'assets';
		else if (currentPath.includes('budgeting')) currentPage = 'budgeting';
		else if (currentPath.includes('procurement')) currentPage = 'procurement';
		
		initializeNavbar(currentPage);
	}
}); 