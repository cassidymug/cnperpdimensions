// Enhanced Navbar Loader for CNPERP ERP
class NavbarLoader {
    constructor() {
        this.navbarContainer = null;
        this.isLoaded = false;
        this.retryCount = 0;
        this.maxRetries = 3;
    }

    // Initialize navbar loading
    init() {
        this.navbarContainer = document.getElementById('navbar-container');
        if (!this.navbarContainer) {
            console.error('❌ Navbar container not found');
            return false;
        }

        console.log('🔍 Navbar container found, starting load...');
        this.loadNavbar();
        return true;
    }

    // Load the navbar with enhanced error handling
    async loadNavbar() {
        try {
            console.log('🔄 Loading navbar...');
            console.log('🔍 Navbar container:', this.navbarContainer);
            
            // Use the createNavbar function from navbar.js (load dynamically if missing)
            if (typeof createNavbar !== 'function') {
                console.warn('⚠️ createNavbar not found. Loading /static/js/navbar.js dynamically...');
                await this.ensureNavbarScriptLoaded(true);
            }

            if (typeof createNavbar === 'function') {
                const currentPage = this.determineCurrentPage();
                console.log('📄 Current page determined:', currentPage);
                let navbarHtml = createNavbar(currentPage);
                console.log('📝 Navbar HTML generated, length:', navbarHtml.length);

                // If the generated HTML doesn't contain the Assets dropdown, force-reload navbar.js and re-render
                if (!navbarHtml.includes('/static/asset-management.html')) {
                    console.warn('⚠️ Assets dropdown not detected in navbar. Forcing navbar.js reload...');
                    await this.ensureNavbarScriptLoaded(true);
                    if (typeof createNavbar === 'function') {
                        navbarHtml = createNavbar(currentPage);
                    }
                }

                this.navbarContainer.innerHTML = navbarHtml;
                console.log('✅ Navbar loaded successfully using createNavbar function');
                this.isLoaded = true;
                this.initializeNavbarFunctionality();
                document.dispatchEvent(new CustomEvent('navbarLoaded', { detail: { success: true } }));
            } else {
                throw new Error('createNavbar function not found after loading navbar.js');
            }
            
        } catch (error) {
            console.error('❌ Error loading navbar:', error);
            this.handleLoadError();
        }
    }

    // Ensure navbar.js is loaded
    ensureNavbarScriptLoaded(forceReload = false) {
        return new Promise((resolve, reject) => {
            const existing = document.getElementById('navbarScript');
            if (existing && !forceReload) {
                // Script already present; give it a tick to initialize
                setTimeout(() => resolve(), 100);
                return;
            }
            if (existing && forceReload) {
                existing.remove();
            }
            const script = document.createElement('script');
            script.id = 'navbarScript';
            // cache-bust to avoid stale cached script
            script.src = '/static/js/navbar.js?v=' + Date.now();
            script.onload = () => resolve();
            script.onerror = () => reject(new Error('Failed to load /static/js/navbar.js'));
            document.head.appendChild(script);
        });
    }

    // Determine current page for navbar highlighting
    determineCurrentPage() {
        const currentPath = window.location.pathname;
        
        if (currentPath.includes('products')) return 'products';
        else if (currentPath.includes('customers')) return 'customers';
        else if (currentPath.includes('sales')) return 'sales';
        else if (currentPath.includes('purchases')) return 'purchases';
        else if (currentPath.includes('suppliers')) return 'suppliers';
        else if (currentPath.includes('bank-accounts')) return 'banking';
        else if (currentPath.includes('bank-transactions')) return 'banking';
        else if (currentPath.includes('bank-transfers')) return 'banking';
        else if (currentPath.includes('bank-reconciliations')) return 'banking';
        else if (currentPath.includes('journal-entries')) return 'accounting';
        else if (currentPath.includes('ledgers')) return 'accounting';
        else if (currentPath.includes('users')) return 'setup';
        else if (currentPath.includes('branches')) return 'setup';
        else if (currentPath.includes('settings')) return 'setup';
        else if (currentPath.includes('pos')) return 'sales';
        else if (currentPath.includes('invoices')) return 'sales';
        else if (currentPath.includes('vat-reconciliations')) return 'tax';
        else if (currentPath.includes('vat-reports')) return 'tax';
        else if (currentPath.includes('purchase-orders')) return 'purchases';
        else if (currentPath.includes('accounting-codes')) return 'accounting';
        else if (currentPath.includes('reports')) return 'accounting';
        else if (currentPath.includes('financial-reports')) return 'tax';
        else if (currentPath.includes('asset-management')) return 'assets';
        else return 'dashboard';
    }

    // Handle navbar load errors with retry logic
    handleLoadError() {
        if (this.retryCount < this.maxRetries) {
            this.retryCount++;
            console.log(`🔄 Retrying navbar load (${this.retryCount}/${this.maxRetries})`);
            setTimeout(() => this.loadNavbar(), 1000 * this.retryCount);
        } else {
            console.warn('⚠️ Max retries reached, using fallback navbar');
            this.createFallbackNavbar();
        }
    }

    // Create a fallback navbar if loading fails
    createFallbackNavbar() {
        const fallbackHtml = `
            <nav class="navbar navbar-expand-lg modern-navbar">
                <div class="container-fluid">
                    <a class="navbar-brand modern-brand fw-bold" href="/static/index.html">
                        <i class="bi bi-building me-2"></i>CNPERP ERP
                    </a>
                    
                    <button class="navbar-toggler modern-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#fallbackNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse" id="fallbackNavbar">
                        <ul class="navbar-nav me-auto">
                            <li class="nav-item">
                                <a class="nav-link modern-nav-link" href="/static/index.html">
                                    <i class="bi bi-speedometer2 me-1"></i>Dashboard
                                </a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle modern-nav-link" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-calculator me-1"></i>Accounting
                                </a>
                                <ul class="dropdown-menu modern-dropdown">
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/accounting-codes.html">Accounting Codes</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/journal-entries.html">Journal Entries</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/ledgers.html">Ledgers</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/reports.html">Reports</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle modern-nav-link" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-box-seam me-1"></i>Inventory
                                </a>
                                <ul class="dropdown-menu modern-dropdown">
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/products.html">Products</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/purchases.html">Purchases</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/purchase-orders.html">Purchase Orders</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle modern-nav-link" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-hdd-stack me-1"></i>Assets
                                </a>
                                <ul class="dropdown-menu modern-dropdown">
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/asset-management.html">Asset Register</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/asset-management.html#depreciation">Depreciation</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/asset-management.html#maintenance">Maintenance</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle modern-nav-link" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-cart me-1"></i>Sales
                                </a>
                                <ul class="dropdown-menu modern-dropdown">
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/customers.html">Customers</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/sales.html">Sales</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/invoices.html">Invoices</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/pos.html">POS</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle modern-nav-link" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-truck me-1"></i>Purchases
                                </a>
                                <ul class="dropdown-menu modern-dropdown">
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/suppliers.html">Suppliers</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/purchases.html">Purchases</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/purchase-orders.html">Orders</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle modern-nav-link" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-bank me-1"></i>Banking
                                </a>
                                <ul class="dropdown-menu modern-dropdown">
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/bank-accounts.html">Bank Accounts</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/bank-transactions.html">Transactions</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/bank-transfers.html">Transfers</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/bank-reconciliations.html">Reconciliations</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle modern-nav-link" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-percent me-1"></i>Tax
                                </a>
                                <ul class="dropdown-menu modern-dropdown">
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/vat-reconciliations.html">VAT Reconciliations</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/vat-reports.html">VAT Reports</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/financial-reports.html">Tax Reports</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/settings.html#vat-settings">VAT Settings</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle modern-nav-link" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-gear me-1"></i>Setup
                                </a>
                                <ul class="dropdown-menu modern-dropdown">
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/branches.html">Branches</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/users.html">Users</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/settings.html">Settings</a></li>
                                </ul>
                            </li>
                        </ul>
                        
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <button class="btn btn-outline-light btn-sm" id="themeToggle" title="Toggle Theme">
                                    <i class="bi bi-moon-fill"></i>
                                </button>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle modern-nav-link" href="#" role="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-person-circle me-1"></i>Admin
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end modern-dropdown">
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/admin-panel.html">Admin Panel</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/users.html">Users</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/settings.html">Settings</a></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="/static/backup-management.html">Backup Management</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item modern-dropdown-item" href="#" onclick="logout()">Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div style="height: 70px;"></div>
        `;
        
        this.navbarContainer.innerHTML = fallbackHtml;
        this.initializeNavbarFunctionality();
        
        // Dispatch event for fallback navbar
        document.dispatchEvent(new CustomEvent('navbarLoaded', { detail: { success: false, fallback: true } }));
    }

    // Initialize all navbar functionality
    initializeNavbarFunctionality() {
        // Wait a bit for DOM to be ready
        setTimeout(() => {
            this.setupThemeSwitcher();
            this.highlightCurrentPage();
            this.setupDropdowns();
            this.setupClickHandlers();
            this.setupLogoutHandler();
        }, 100);
    }

    // Setup theme switcher
    setupThemeSwitcher() {
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            const icon = themeToggle.querySelector('i');
            
            // Check for saved theme preference
            const currentTheme = localStorage.getItem('theme') || 'light';
            document.body.setAttribute('data-theme', currentTheme);
            this.updateThemeIcon(currentTheme);
            
            themeToggle.addEventListener('click', () => {
                const currentTheme = document.body.getAttribute('data-theme');
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.body.setAttribute('data-theme', newTheme);
                localStorage.setItem('theme', newTheme);
                this.updateThemeIcon(newTheme);
            });
        }
    }

    // Update theme icon
    updateThemeIcon(theme) {
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            const icon = themeToggle.querySelector('i');
            if (theme === 'dark') {
                icon.className = 'bi bi-sun-fill';
                themeToggle.title = 'Switch to Light Mode';
            } else {
                icon.className = 'bi bi-moon-fill';
                themeToggle.title = 'Switch to Dark Mode';
            }
        }
    }

    // Highlight current page in navigation
    highlightCurrentPage() {
        const currentPath = window.location.pathname;
        const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
        
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href && href === currentPath) {
                link.classList.add('active');
            }
        });
    }

    // Setup Bootstrap dropdowns
    setupDropdowns() {
        if (typeof bootstrap !== 'undefined') {
            const dropdownElementList = document.querySelectorAll('.dropdown-toggle');
            dropdownElementList.forEach(dropdownToggleEl => {
                new bootstrap.Dropdown(dropdownToggleEl);
            });
        }
    }

    // Setup click handlers for navigation links
    setupClickHandlers() {
        const allNavLinks = document.querySelectorAll('.navbar-nav a');
        allNavLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                // Don't prevent default for dropdown toggles
                if (link.classList.contains('dropdown-toggle')) {
                    return;
                }
                
                // For logout, handle specially
                if (link.getAttribute('onclick') === 'logout()') {
                    e.preventDefault();
                    this.handleLogout();
                    return;
                }
                
                // For other links, ensure they work properly
                const href = link.getAttribute('href');
                if (href && href !== '#' && !href.startsWith('javascript:')) {
                    // Add loading indicator if modernUI is available
                    if (window.modernUI) {
                        window.modernUI.showNotification('Navigating...', 'info');
                    }
                }
            });
        });
    }

    // Setup logout handler
    setupLogoutHandler() {
        // Override the global logout function
        window.logout = () => this.handleLogout();
    }

    // Handle logout
    handleLogout() {
        if (confirm('Are you sure you want to logout?')) {
            // Clear stored data
            localStorage.removeItem('theme');
            sessionStorage.clear();
            
            // Show logout notification
            if (window.modernUI) {
                window.modernUI.showNotification('Logging out...', 'info');
            }
            
            // Redirect to home page
            setTimeout(() => {
                window.location.href = '/static/index.html';
            }, 1000);
        }
    }

    // Check if navbar is loaded
    isNavbarLoaded() {
        return this.isLoaded;
    }

    // Get navbar status
    getStatus() {
        return {
            loaded: this.isLoaded,
            retryCount: this.retryCount,
            containerExists: !!this.navbarContainer
        };
    }
}

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.navbarLoader = new NavbarLoader();
    window.navbarLoader.init();
});

// Export for manual initialization
if (typeof module !== 'undefined' && module.exports) {
    module.exports = NavbarLoader;
} 