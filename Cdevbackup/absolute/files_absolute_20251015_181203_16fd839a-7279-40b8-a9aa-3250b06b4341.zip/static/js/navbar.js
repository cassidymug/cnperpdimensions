// Simple navbar for journal-entries.html - Standard CNPERP navbar system

// Function to add fallback styles when Bootstrap Icons are not available
function addOfflineStyles() {
	if (!document.getElementById('navbar-fallback-styles')) {
		const style = document.createElement('style');
		style.id = 'navbar-fallback-styles';
		style.textContent = `
			.navbar { background: linear-gradient(135deg, #0d6efd, #0056b3) !important; }
			.navbar-brand, .nav-link { color: white !important; }
			.nav-link:hover { color: #e6f3ff !important; }
			.dropdown-menu { background-color: white; border: 1px solid #dee2e6; box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15); }
			.dropdown-item { color: #212529; padding: 0.5rem 1rem; text-decoration: none; display: block; }
			.dropdown-item:hover { background-color: #f8f9fa; color: #212529; }
			.dropdown-divider { border-top: 1px solid #dee2e6; margin: 0.5rem 0; }
			.bi { display: inline-block; width: 1em; height: 1em; vertical-align: -0.125em; }
			.bi-building::before { content: "🏢"; }
			.bi-speedometer2::before { content: "📊"; }
			.bi-calculator::before { content: "🧮"; }
			.bi-cart::before { content: "🛒"; }
			.bi-box-seam::before { content: "📦"; }
			.bi-truck::before { content: "🚚"; }
			.bi-buildings::before { content: "🏭"; }
			.bi-receipt::before { content: "🧾"; }
			.bi-clipboard-check::before { content: "📋"; }
			.bi-bank::before { content: "🏦"; }
			.bi-hdd-stack::before { content: "💾"; }
			.bi-gear::before { content: "⚙️"; }
			.bi-person-circle::before { content: "👤"; }
			.bi-credit-card::before { content: "💳"; }
			.bi-cash-stack::before { content: "💰"; }
			.bi-graph-up::before { content: "📈"; }
		`;
		document.head.appendChild(style);
	}
}

function createNavbar(currentPage = 'dashboard') {
	// Add offline styles first
	try {
		addOfflineStyles();
	} catch (e) {
		console.warn('Could not add offline styles:', e);
	}
	
	// Create navbar HTML with error handling
	try {
		const navbarHtml = `<nav class="navbar navbar-expand-lg">
<div class="container-fluid">
	<a class="navbar-brand" href="/static/index.html">
		<span class="bi bi-building"></span> CNPERP ERP
	</a>
	
	<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarContent">
		<ul class="navbar-nav me-auto">
			<li class="nav-item">
				<a class="nav-link ${currentPage === 'dashboard' ? 'active' : ''}" href="/static/index.html">
					<span class="bi bi-speedometer2"></span> Dashboard
				</a>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'pos' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-cash-stack"></span> POS
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/pos.html">POS Terminal</a></li>
					<li><a class="dropdown-item" href="/static/pos_new.html">New POS</a></li>
					<li><a class="dropdown-item" href="/static/pos-reconciliation.html">POS Reconciliation</a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'sales' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-cart"></span> Sales
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/sales.html">Sales Management</a></li>
					<li><a class="dropdown-item" href="/static/customers.html">Customers</a></li>
					<li><a class="dropdown-item" href="/static/invoices.html">Invoices</a></li>
					<li><a class="dropdown-item" href="/static/quotations.html">Quotations</a></li>
					<li><a class="dropdown-item" href="/static/job-cards.html">Job Cards</a></li>
					<li><a class="dropdown-item" href="/static/credit-notes.html">Credit Notes</a></li>
					<li><a class="dropdown-item" href="/static/receipts.html">Receipts</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/sales-reports.html">Sales Reports</a></li>
					<li><a class="dropdown-item" href="/static/customer-reports.html">Customer Reports</a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'purchases' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-truck"></span> Purchases
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/purchases.html">Purchase Management</a></li>
					<li><a class="dropdown-item" href="/static/purchase-orders.html">Purchase Orders</a></li>
					<li><a class="dropdown-item" href="/static/suppliers.html">Suppliers</a></li>
					<li><a class="dropdown-item" href="/static/purchase-payments.html">Purchase Payments</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/purchase-reports.html">Purchase Reports</a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'inventory' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-box-seam"></span> Inventory
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/products.html">Products</a></li>
					<li><a class="dropdown-item" href="/static/inventory-allocation.html">Inventory Allocation</a></li>
					<li><a class="dropdown-item" href="/static/manufacturing.html"><span class="bi bi-gear me-2"></span>Manufacturing</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/inventory-reports.html">Inventory Reports</a></li>
					<li><a class="dropdown-item" href="/static/cogs.html">COGS Management</a></li>
					<li><a class="dropdown-item" href="/static/cogs-reports.html">COGS Reports</a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'procurement' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-truck"></span> Procurement
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/procurement.html">Procurement Management</a></li>
					<li><a class="dropdown-item" href="/static/landed-costs.html">Landed Costs</a></li>
					<li><a class="dropdown-item" href="/static/purchase-orders.html">Purchase Orders</a></li>
					<li><a class="dropdown-item" href="/static/suppliers.html">Suppliers</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/purchase-reports.html">Procurement Reports</a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'assets' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-buildings"></span> Assets
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/asset-management.html">Asset Management</a></li>
					<li><a class="dropdown-item" href="/static/asset.html">Assets</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/asset-reports.html">Asset Reports</a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'taxes' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-receipt"></span> Taxes
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/vat-reports.html">VAT Reports</a></li>
					<li><a class="dropdown-item" href="/static/vat-reconciliations.html">VAT Reconciliations</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/budgeting.html">Tax Planning</a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'banking' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-bank"></span> Banking
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/bank-accounts.html">Bank Accounts</a></li>
					<li><a class="dropdown-item" href="/static/bank-transactions.html">Bank Transactions</a></li>
					<li><a class="dropdown-item" href="/static/bank-transfers.html">Bank Transfers</a></li>
					<li><a class="dropdown-item" href="/static/bank-reconciliations.html">Bank Reconciliations</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/banking-reports.html">Banking Reports</a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'accounting' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-calculator"></span> Accounting
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/journal-entries.html">Journal Entries</a></li>
					<li><a class="dropdown-item" href="/static/ledgers.html">Ledgers</a></li>
					<li><a class="dropdown-item" href="/static/chart-of-accounts.html">Chart of Accounts</a></li>
					<li><a class="dropdown-item" href="/static/accounting-codes.html">Accounting Codes</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/budgeting.html">Budgeting</a></li>
					<li><a class="dropdown-item" href="/static/financial-reports.html">Financial Reports</a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'reports' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-graph-up"></span> Reports
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/reports.html">All Reports</a></li>
					<li><a class="dropdown-item" href="/static/financial-reports.html">Financial Reports</a></li>
					<li><a class="dropdown-item" href="/static/management-reports.html">Management Reports</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/sales-reports.html">Sales Reports</a></li>
					<li><a class="dropdown-item" href="/static/purchase-reports.html">Purchase Reports</a></li>
					<li><a class="dropdown-item" href="/static/inventory-reports.html">Inventory Reports</a></li>
					<li><a class="dropdown-item" href="/static/customer-reports.html">Customer Reports</a></li>
					<li><a class="dropdown-item" href="/static/banking-reports.html">Banking Reports</a></li>
					<li><a class="dropdown-item" href="/static/asset-reports.html">Asset Reports</a></li>
					<li><a class="dropdown-item" href="/static/invoice-reports.html">Invoice Reports</a></li>
					<li><a class="dropdown-item" href="/static/cogs-reports.html">COGS Reports</a></li>
				</ul>
			</li>
			<li class="nav-item">
				<a class="nav-link ${currentPage === 'business-intelligence' ? 'active' : ''}" href="/static/business-intelligence.html">
					<span class="bi bi-graph-up-arrow"></span> Business Intelligence
				</a>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle ${currentPage === 'settings' ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-gear"></span> Settings
				</a>
				<ul class="dropdown-menu">
					<li><a class="dropdown-item" href="/static/settings.html">System Settings</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/admin-panel.html">Admin Panel</a></li>
					<li><a class="dropdown-item" href="/static/users.html">Users</a></li>
					<li><a class="dropdown-item" href="/static/user-permissions.html">User Permissions</a></li>
					<li><a class="dropdown-item" href="/static/role-management.html">Role Management</a></li>
					<li><a class="dropdown-item" href="/static/permission-matrix.html">Permission Matrix</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/static/backup-management.html">Backup Management</a></li>
					<li><a class="dropdown-item ${currentPage === 'excel-templates' ? 'active' : ''}" href="/static/excel-templates.html">Excel Templates</a></li>
					<li><a class="dropdown-item" href="/static/invoice-customization.html">Invoice Customization</a></li>
					<li><a class="dropdown-item" href="/static/invoice-designer.html">Invoice Designer</a></li>
					<li><a class="dropdown-item" href="/static/invoice-printer-settings.html">Print Settings</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><h6 class="dropdown-header">Help & Documentation</h6></li>
					<li><a class="dropdown-item" href="/help-center">
						<span class="bi bi-question-circle"></span> Help Center
					</a></li>
					<li><a class="dropdown-item" href="/static/weight-barcode-generator.html">
						<span class="bi bi-upc-scan"></span> Barcode Generator
					</a></li>
				</ul>
			</li>
		</ul>
		
		<ul class="navbar-nav">
			<li class="nav-item">
				<div class="nav-link d-flex align-items-center">
					<span class="bi bi-person-circle me-2"></span>
					<div class="d-flex flex-column">
						<small class="text-white-50" style="font-size: 0.75rem;">Logged in as</small>
						<span id="current-user-display" class="text-white fw-bold" style="font-size: 0.9rem;">Loading...</span>
						<small id="current-branch-display" class="text-white-50" style="font-size: 0.7rem;">Branch: Loading...</small>
					</div>
				</div>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
					<span class="bi bi-gear"></span>
				</a>
				<ul class="dropdown-menu dropdown-menu-end">
					<li><a class="dropdown-item" href="/static/admin-panel.html">
						<span class="bi bi-speedometer2"></span> Admin Panel
					</a></li>
					<li><a class="dropdown-item" href="/static/users.html">
						<span class="bi bi-people"></span> Users
					</a></li>
					<li><a class="dropdown-item" href="/static/settings.html">
						<span class="bi bi-gear"></span> Settings
					</a></li>
					<li><a class="dropdown-item" href="/static/backup-management.html">
						<span class="bi bi-cloud-upload"></span> Backup Management
					</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="/help-center">
						<span class="bi bi-question-circle"></span> Help Center
					</a></li>
					<li><hr class="dropdown-divider"></li>
					<li><a class="dropdown-item" href="#" onclick="logout()">
						<span class="bi bi-box-arrow-right"></span> Logout
					</a></li>
				</ul>
			</li>
		</ul>
	</div>
</div>
</nav>`;
		
		console.log('✅ Navbar HTML generated successfully (v20251015-HELPCENTER), length:', navbarHtml.length);
		console.log('✅ Help menu now points to main Help Center at /help-center');
		return navbarHtml;
	} catch (error) {
		console.error('Error creating navbar HTML:', error);
		// Return a minimal fallback navbar
		return `<nav class="navbar navbar-expand-lg bg-primary">
			<div class="container-fluid">
				<a class="navbar-brand text-white" href="/static/index.html">CNPERP ERP</a>
				<ul class="navbar-nav">
					<li class="nav-item">
						<a class="nav-link text-white" href="/static/journal-entries.html">Journal Entries</a>
					</li>
				</ul>
			</div>
		</nav>`;
	}
}

// Function to update user display in navbar
function updateUserDisplay() {
	const userDisplay = document.getElementById('current-user-display');
	const branchDisplay = document.getElementById('current-branch-display');
	
	if (userDisplay && branchDisplay) {
		if (window.auth && auth.isAuthenticated()) {
			const user = auth.getUser();
			if (user) {
				// Display username
				const username = user.username || 'Unknown User';
				userDisplay.textContent = username;
				
				// Display branch information
				const branchCode = user.branch_code || 'No Branch';
				branchDisplay.textContent = `Branch: ${branchCode}`;
			} else {
				userDisplay.textContent = 'Not logged in';
				branchDisplay.textContent = 'Branch: N/A';
			}
		} else {
			userDisplay.textContent = 'Not logged in';
			branchDisplay.textContent = 'Branch: N/A';
		}
	}
}

// Function to initialize navbar on any page
function initializeNavbar(currentPage = 'dashboard') {
	// Remove any existing navbars to enforce a single consistent navbar
	try {
		document.querySelectorAll('nav.navbar').forEach(el => {
			// If this is inside our container, we'll replace it anyway
			el.remove();
		});
	} catch (e) {
		console.warn('Navbar cleanup warning:', e);
	}

	// Ensure a container exists at the very top of the body
	let navbarContainer = document.getElementById('navbar-container');
	if (!navbarContainer) {
		navbarContainer = document.createElement('div');
		navbarContainer.id = 'navbar-container';
		if (document.body.firstChild) {
			document.body.insertBefore(navbarContainer, document.body.firstChild);
		} else {
			document.body.appendChild(navbarContainer);
		}
	}

	// Inject our standardized navbar
	navbarContainer.innerHTML = createNavbar(currentPage);
	console.log('✅ Navbar loaded successfully with Manufacturing link included');
	// Update user display after navbar is created
	setTimeout(updateUserDisplay, 100);
}

// Function to handle logout
function logout() {
	// Prefer the enhanced loader confirm if present
	if (typeof window.navbarLoader !== 'undefined' && typeof window.navbarLoader.handleLogout === 'function') {
		window.navbarLoader.handleLogout();
		return;
	}
	// Prefer auth.js if available (handles broadcast + cleanup)
	if (window.auth && typeof auth.logout === 'function') {
		auth.logout();
		return;
	}
	// Fallback: clear known token keys and redirect
	try {
		// Primary keys used by auth.js
		localStorage.removeItem('token');
		localStorage.removeItem('user');
		localStorage.removeItem('token_exp');
		// Back-compat older keys
		localStorage.removeItem('user_token');
		localStorage.removeItem('user_data');
	} catch(e) { console.warn('Logout fallback error', e); }
	window.location.replace('/static/login.html');
}

// Check if Bootstrap is available
function isBootstrapAvailable() {
	return typeof bootstrap !== 'undefined' && bootstrap.Modal;
}

// Add basic Bootstrap functionality if not available
function addBootstrapFallback() {
	if (!isBootstrapAvailable()) {
		console.log('⚠️ Bootstrap not available, adding fallback functionality');
		
		// Add basic dropdown functionality
		document.addEventListener('click', function(e) {
			if (e.target.classList.contains('dropdown-toggle')) {
				e.preventDefault();
				const dropdown = e.target.closest('.dropdown');
				const menu = dropdown.querySelector('.dropdown-menu');
				
				// Close other dropdowns
				document.querySelectorAll('.dropdown-menu').forEach(m => {
					if (m !== menu) m.style.display = 'none';
				});
				
				// Toggle current dropdown
				menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
			} else if (!e.target.closest('.dropdown')) {
				// Close all dropdowns when clicking outside
				document.querySelectorAll('.dropdown-menu').forEach(m => {
					m.style.display = 'none';
				});
			}
		});
		
		// Add basic collapse functionality
		document.addEventListener('click', function(e) {
			if (e.target.classList.contains('navbar-toggler')) {
				e.preventDefault();
				const target = e.target.getAttribute('data-bs-target');
				const element = document.querySelector(target);
				if (element) {
					element.classList.toggle('show');
				}
			}
		});
	}
}

// Auto-initialize navbar if navbar-container exists
document.addEventListener('DOMContentLoaded', function() {
	// Add Bootstrap fallback
	addBootstrapFallback();

	// Determine current page from URL
	const currentPath = window.location.pathname;
	let currentPage = 'dashboard';
	
	// POS Pages
	if (currentPath.includes('pos')) currentPage = 'pos';
	
	// Sales Pages  
	else if (currentPath.includes('sales') || currentPath.includes('customers') || currentPath.includes('invoices') || 
	         currentPath.includes('quotations') || currentPath.includes('job-cards') || currentPath.includes('credit-notes')) currentPage = 'sales';
	
	// Purchase Pages
	else if (currentPath.includes('purchases') || currentPath.includes('purchase-orders') || currentPath.includes('suppliers') || 
	         currentPath.includes('purchase-payments') || currentPath.includes('receipts')) currentPage = 'purchases';
	
	// Procurement Pages
	else if (currentPath.includes('procurement') || currentPath.includes('landed-costs')) currentPage = 'procurement';
	
	// Inventory Pages
	else if (currentPath.includes('products') || currentPath.includes('inventory') || currentPath.includes('manufacturing') || 
	         currentPath.includes('cogs')) currentPage = 'inventory';
	
	// Assets Pages
	else if (currentPath.includes('asset')) currentPage = 'assets';
	
	// Taxes Pages
	else if (currentPath.includes('vat') || currentPath.includes('tax')) currentPage = 'taxes';
	
	// Banking Pages
	else if (currentPath.includes('bank')) currentPage = 'banking';
	
	// Accounting Pages
	else if (currentPath.includes('journal-entries') || currentPath.includes('accounting') || currentPath.includes('ledgers') || 
	         currentPath.includes('chart-of-accounts') || currentPath.includes('budgeting') || 
	         currentPath.includes('financial-reports')) currentPage = 'accounting';
	
	// Reports Pages
	else if (currentPath.includes('reports')) currentPage = 'reports';
	
	// Settings/Admin Pages
	else if (currentPath.includes('settings') || currentPath.includes('users') || currentPath.includes('admin') || 
	         currentPath.includes('permissions') || currentPath.includes('role') || 
	         currentPath.includes('backup') || currentPath.includes('invoice-customization') || currentPath.includes('invoice-designer') || 
	         currentPath.includes('invoice-printer')) currentPage = 'settings';

	initializeNavbar(currentPage);
});