# Code Citations

## License: GPL-3.0
https://github.com/mattgodbolt/jsbeeb/blob/aaeabbf49fd86490a7ec65575e3845be6efa2692/index.html

```
<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <
```

